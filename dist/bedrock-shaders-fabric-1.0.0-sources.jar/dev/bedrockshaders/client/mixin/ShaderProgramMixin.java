package dev.bedrockshaders.client.mixin;

import dev.bedrockshaders.client.render.BedrockUniforms;
import dev.bedrockshaders.client.render.FrameContext;
import dev.bedrockshaders.client.render.RenderCompat;
import net.minecraft.class_5944;
import org.lwjgl.opengl.GL20;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Uploads the Bedrock uniforms right after vanilla binds a core shader program,
 * which is the only moment the program is guaranteed to be current.
 */
@Mixin(class_5944.class)
public abstract class ShaderProgramMixin {
    @Inject(method = "bind()V", at = @At("TAIL"))
    private void bedrockShaders$afterBind(CallbackInfo ci) {
        // glUseProgram is not even defined under VulkanMod, and Iris owns these programs.
        if (!RenderCompat.get().allowsGlWork()) {
            return;
        }
        class_5944 self = (class_5944) (Object) this;
        if (!BedrockUniforms.isTarget(self.method_35787())) {
            return;
        }
        FrameContext context = FrameContext.get();
        if (!context.isActive()) {
            return;
        }
        GL20.glUseProgram(self.method_1270());
        BedrockUniforms.bind(self);
        BedrockUniforms.apply(self, context, BedrockUniforms.glossFor(self.method_35787()));
    }
}
