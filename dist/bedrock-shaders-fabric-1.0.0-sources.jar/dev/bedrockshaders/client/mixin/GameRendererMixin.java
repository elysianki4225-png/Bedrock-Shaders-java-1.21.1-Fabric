package dev.bedrockshaders.client.mixin;

import dev.bedrockshaders.client.render.BedrockPipeline;
import dev.bedrockshaders.client.render.FrameContext;
import net.minecraft.class_310;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Begins the Bedrock frame, runs the post stack after the world+HUD are drawn and
 * releases GL resources when the renderer shuts down.
 */
@Mixin(class_757.class)
public abstract class GameRendererMixin {
    @Inject(method = "renderWorld(Lnet/minecraft/client/render/RenderTickCounter;)V", at = @At("HEAD"))
    private void bedrockShaders$beginWorld(class_9779 tickCounter, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return;
        }
        FrameContext context = FrameContext.get();
        context.beginFrame(dev.bedrockshaders.client.FabricClientSnapshot.get());
        BedrockPipeline.get().ensureInitialized();
        if (client.field_1687 != null && client.method_1560() != null && context.isActive()) {
            // Mirrors the view matrix vanilla builds for the world pass, including hurt tilt.
            Matrix4f view = new Matrix4f();
            view.rotate(class_7833.field_40714.rotationDegrees(client.field_1773.method_19418().method_19329()));
            view.rotate(class_7833.field_40716.rotationDegrees(client.field_1773.method_19418().method_19330() + 180.0F));
            context.setView(view);
            context.setProjection(com.mojang.blaze3d.systems.RenderSystem.getProjectionMatrix());
        }
    }

    @Inject(method = "render(Lnet/minecraft/client/render/RenderTickCounter;Z)V", at = @At("TAIL"))
    private void bedrockShaders$afterFrame(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        FrameContext context = FrameContext.get();
        BedrockPipeline pipeline = BedrockPipeline.get();
        if (!context.isActive()) {
            return;
        }
        if (client.field_1687 != null && pipeline.isReady() && pipeline.wantsEffects()) {
            pipeline.renderEffects(context);
        }
        context.endFrame();
    }

    @Inject(method = "close()V", at = @At("HEAD"))
    private void bedrockShaders$close(CallbackInfo ci) {
        BedrockPipeline.get().close();
    }
}
