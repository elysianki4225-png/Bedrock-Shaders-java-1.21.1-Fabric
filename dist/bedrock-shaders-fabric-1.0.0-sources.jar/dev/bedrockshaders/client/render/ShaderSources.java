package dev.bedrockshaders.client.render;

import dev.bedrockshaders.BedrockShadersMod;
import dev.bedrockshaders.client.assets.ResourceSource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Loads the Bedrock shader sources that ship in the jar at
 * {@code assets/bedrock_shaders/bedrockshader/*} and prepares them for vanilla's
 * core-shader importer by flattening {@code #moj_import <...>} includes.
 *
 * <p>Sources are reloaded on resource reloads so pack overrides are respected.</p>
 */
public final class ShaderSources {
    private static final String ROOT = "bedrockshader/";
    private static final Map<String, String> CACHE = new HashMap<>();

    private ShaderSources() {
    }

    /** Mod-relative path of a shader source, e.g. {@code bedrockshader/core/x.vsh}. */
    public static String path(String stage) {
        return ROOT + stage;
    }

    public static void clearCache() {
        CACHE.clear();
    }

    /** Returns the fully flattened GLSL for {@code core/<name>.vsh|fsh}. */
    public static String get(ResourceSource manager, String stage) {
        String cached = CACHE.get(stage);
        if (cached != null) {
            return cached;
        }
        String source = readRaw(manager, "core/" + stage);
        String flattened = flatten(manager, source, 0);
        CACHE.put(stage, flattened);
        return flattened;
    }

    private static String readRaw(ResourceSource manager, String relative) {
        // Every read is relative to this mod's own asset namespace, so ROOT has to be
        // applied here rather than at each call site. It is not: without it the lookup asks
        // for bedrock_shaders:core/x.vsh while the jar ships
        // assets/bedrock_shaders/bedrockshader/core/x.vsh, and every resource reload logs
        // "Missing Bedrock shader source" and then fails to generate the runtime pack.
        String path = path(relative);
        InputStream stream = manager.open(path);
        if (stream == null) {
            throw new IllegalStateException("Missing Bedrock shader source " + path);
        }
        try (InputStream in = stream) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException("Could not read " + path, e);
        }
    }

    /**
     * Flattens {@code #moj_import <name>} directives exactly like vanilla's
     * {@code GlImportProcessor}, but also supports {@code #moj_import "name"}.
     * Include files must reside under {@code bedrockshader/include/}.
     */
    public static String flatten(ResourceSource manager, String source, int depth) {
        if (depth > 8) {
            throw new IllegalStateException("Bedrock shader include depth exceeded");
        }
        StringBuilder out = new StringBuilder(source.length() + 4096);
        for (String line : source.split("\n", -1)) {
            String trimmed = line.trim();
            if (trimmed.startsWith("#moj_import")) {
                String target = trimmed.substring("#moj_import".length()).trim();
                if (target.startsWith("<") && target.endsWith(">")) {
                    target = target.substring(1, target.length() - 1);
                } else if (target.startsWith("\"") && target.endsWith("\"")) {
                    target = target.substring(1, target.length() - 1);
                }
                String included = flatten(manager, readRaw(manager, "include/" + target), depth + 1);
                out.append("// begin ").append(target).append('\n');
                out.append(included);
                out.append("// end ").append(target).append('\n');
            } else {
                out.append(line);
                out.append('\n');
            }
        }
        return out.toString();
    }

    /** Called by each loader's resource reload listener. */
    public static void reload(ResourceSource manager) {
        clearCache();
        for (String stage : new String[] {
                "bedrock_terrain.vsh", "bedrock_terrain.fsh",
                "bedrock_translucent.vsh", "bedrock_translucent.fsh",
                "bedrock_entity.vsh", "bedrock_entity.fsh"}) {
            try {
                ShaderSources.get(manager, stage);
            } catch (RuntimeException e) {
                BedrockShadersMod.LOGGER.warn("Bedrock shader source {} unavailable", stage, e);
            }
        }
    }
}
