package dev.bedrockshaders.client.gui;

import dev.bedrockshaders.client.pack.BedrockPackImporter;
import dev.bedrockshaders.client.pack.ImportedPack;
import dev.bedrockshaders.client.pack.ImportedPackActivator;
import dev.bedrockshaders.client.pack.PackRegistry;
import dev.bedrockshaders.config.ShaderFamily;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Iris-style pack browser: lists every imported Bedrock pack, toggles it, opens the
 * import folder, imports a {@code .mcpack} by path, and links to vanilla's resource-pack
 * screen. Importing never needs a restart - the list refreshes and the pack stack is
 * resynced immediately.
 */
public final class BedrockPacksScreen extends class_437 {
    private static final int ROW_HEIGHT = 24;

    private final class_437 parent;
    private class_342 pathField;
    private String status = "";
    private int statusColor = 0xA0A0A0;
    private int scroll;
    private int rowsPerPage;

    public BedrockPacksScreen(class_437 parent) {
        super(class_2561.method_43471("bedrock_shaders.packs.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        PackRegistry.get().ensureFolders();
        rowsPerPage = Math.max(3, (field_22790 - 132) / ROW_HEIGHT);
        int left = field_22789 / 2 - 150;

        method_37063(class_4185.method_46430(class_2561.method_43471("bedrock_shaders.packs.open_folder"), button -> {
            openFolder();
        }).method_46434(left, field_22790 - 84, 145, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43471("bedrock_shaders.packs.rescan"), button -> {
            rescan();
        }).method_46434(left + 155, field_22790 - 84, 145, 20).method_46431());

        pathField = new class_342(field_22793, left, field_22790 - 60, 215, 20,
                class_2561.method_43471("bedrock_shaders.packs.path_hint"));
        pathField.method_1880(512);
        pathField.method_47404(class_2561.method_43471("bedrock_shaders.packs.path_hint"));
        method_37063(pathField);

        method_37063(class_4185.method_46430(class_2561.method_43471("bedrock_shaders.packs.import_path"), button -> {
            importPath();
        }).method_46434(left + 220, field_22790 - 60, 80, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43471("bedrock_shaders.packs.vanilla_screen"), button -> {
            class_310 client = class_310.method_1551();
            client.method_1507(new net.minecraft.class_5375(
                    client.method_1520(),
                    manager -> client.field_1690.method_49598(manager),
                    PackRegistry.generatedFolder(),
                    class_2561.method_43471("bedrock_shaders.packs.vanilla_screen")));
        }).method_46434(left, field_22790 - 36, 300, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), button -> method_25419())
                .method_46434(field_22789 / 2 - 50, field_22790 - 12, 100, 12).method_46431());
    }

    private void openFolder() {
        PackRegistry.get().ensureFolders();
        class_156.method_668().method_60932(PackRegistry.importFolder());
        setStatus(class_2561.method_43471("bedrock_shaders.packs.status.opened").getString(), 0x80C080);
    }

    private void rescan() {
        PackRegistry.get().reloadFromDisk();
        List<BedrockPackImporter.Result> results = PackRegistry.get().importPending();
        ImportedPackActivator.invalidate();
        int ok = 0;
        int failed = 0;
        for (BedrockPackImporter.Result result : results) {
            if (result.success()) {
                ok++;
            } else {
                failed++;
            }
        }
        ImportedPackActivator.reload(class_310.method_1551());
        setStatus(class_2561.method_43469("bedrock_shaders.packs.status.scanned", ok, failed).getString(),
                failed == 0 ? 0x80C080 : 0xE0C060);
        rebuild();
    }

    private void importPath() {
        String raw = pathField == null ? "" : pathField.method_1882().trim();
        if (raw.isEmpty()) {
            setStatus(class_2561.method_43471("bedrock_shaders.packs.status.need_path").getString(), 0xE08080);
            return;
        }
        Path path = Path.of(raw);
        if (!Files.isRegularFile(path)) {
            setStatus(class_2561.method_43469("bedrock_shaders.packs.status.no_file", raw).getString(), 0xE08080);
            return;
        }
        BedrockPackImporter.Result result = PackRegistry.get().importFile(path);
        ImportedPackActivator.invalidate();
        ImportedPackActivator.reload(class_310.method_1551());
        if (result.success()) {
            setStatus(class_2561.method_43469("bedrock_shaders.packs.status.imported",
                    result.pack().displayName, result.pack().totalDataFiles()).getString(), 0x80C080);
        } else {
            setStatus(class_2561.method_43469("bedrock_shaders.packs.status.failed", result.message()).getString(), 0xE08080);
        }
        rebuild();
    }

    private void rebuild() {
        this.method_37067();
        this.method_25426();
    }

    private void setStatus(String message, int color) {
        this.status = message;
        this.statusColor = color;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_52752(context);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 8, 0xFFFFFF);
        context.method_27534(field_22793,
                class_2561.method_43469("bedrock_shaders.packs.subtitle", PackRegistry.importFolder().toString()),
                field_22789 / 2, 22, 0x9BB7D4);

        List<ImportedPack> packs = PackRegistry.get().imported();
        int left = field_22789 / 2 - 150;
        if (packs.isEmpty()) {
            context.method_27534(field_22793,
                    class_2561.method_43471("bedrock_shaders.packs.empty"),
                    field_22789 / 2, 56, 0xC0C0C0);
            context.method_27534(field_22793,
                    class_2561.method_43471("bedrock_shaders.packs.empty_hint"),
                    field_22789 / 2, 72, 0x909090);
        } else {
            int start = Math.min(scroll, Math.max(0, packs.size() - 1));
            for (int i = 0; i < Math.min(rowsPerPage, packs.size() - start); i++) {
                ImportedPack pack = packs.get(start + i);
                drawRow(context, pack, left, 40 + i * ROW_HEIGHT);
            }
        }

        if (!status.isEmpty()) {
            context.method_27534(field_22793, class_2561.method_43470(status), field_22789 / 2, field_22790 - 96, statusColor);
        }
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void drawRow(class_332 context, ImportedPack pack, int x, int y) {
        int width = 300;
        boolean hovered = false;
        context.method_25294(x, y, x + width, y + ROW_HEIGHT - 2, hovered ? 0x90202A38 : 0x80141A22);
        String name = pack.displayName + " " + pack.version;
        context.method_27535(field_22793, class_2561.method_43470(name), x + 4, y + 4, 0xFFFFFF);
        // Show the recognised family next to the counts: it explains why a Newb pack looks
        // different from a generic one, and tells the user the tuning is intentional.
        var family = pack.shaderFamily();
        if (family != dev.bedrockshaders.config.ShaderFamily.GENERIC) {
            String badge = class_2561.method_43471(family.translationKey).getString();
            int badgeWidth = field_22793.method_1727(badge) + 6;
            context.method_25294(x + width - 100 - badgeWidth, y + 3, x + width - 100, y + 13, 0x60204030);
            context.method_27535(field_22793, class_2561.method_43470(badge),
                    x + width - 100 - badgeWidth + 3, y + 4, 0x9FE0B0);
        }
        context.method_27535(field_22793, class_2561.method_43470(pack.describe()), x + 4, y + 14, 0x8899AA);

        int toggleX = x + width - 96;
        class_4185 toggle = class_4185.method_46430(
                        class_2561.method_43471(pack.enabled ? "bedrock_shaders.packs.on" : "bedrock_shaders.packs.off"),
                        button -> {
                            PackRegistry.get().setEnabled(pack.fileName, !pack.enabled);
                            ImportedPackActivator.invalidate();
                            ImportedPackActivator.reload(class_310.method_1551());
                            rebuild();
                        })
                .method_46434(toggleX, y + 2, 44, 18).method_46431();
        method_37063(toggle);

        method_37063(class_4185.method_46430(class_2561.method_43471("bedrock_shaders.packs.delete"), button -> {
            PackRegistry.get().delete(pack.fileName);
            ImportedPackActivator.invalidate();
            ImportedPackActivator.reload(class_310.method_1551());
            setStatus(class_2561.method_43469("bedrock_shaders.packs.status.deleted", pack.displayName).getString(), 0xE0C060);
            rebuild();
        }).method_46434(toggleX + 48, y + 2, 44, 18).method_46431());
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int packCount = PackRegistry.get().imported().size();
        int maxScroll = Math.max(0, packCount - rowsPerPage);
        if (maxScroll > 0) {
            scroll = Math.max(0, Math.min(maxScroll, scroll - (int) Math.signum(verticalAmount)));
            rebuild();
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void method_25419() {
        class_310 client = class_310.method_1551();
        client.method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
