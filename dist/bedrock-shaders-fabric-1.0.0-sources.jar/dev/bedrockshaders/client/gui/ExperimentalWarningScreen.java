package dev.bedrockshaders.client.gui;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

/**
 * A modal warning shown before an experimental feature is switched on, and when a pack
 * turns out to need it.
 *
 * <p>Two rules make it a warning rather than a nag:</p>
 * <ul>
 *   <li>it always names the specific limitation, not "may cause issues";</li>
 *   <li>it is only ever shown when something is actually being enabled or refused, so a
 *       user who never touches the feature never sees it.</li>
 * </ul>
 */
public class ExperimentalWarningScreen extends class_437 {

    /** What the warning is about; keeps the strings in the language files. */
    public enum Kind {
        ENABLE_RENDER_DRAGON("bedrock_shaders.warn.renderdragon.title",
                "bedrock_shaders.warn.renderdragon.body"),
        RENDER_DRAGON_PACK("bedrock_shaders.warn.dragon_pack.title",
                "bedrock_shaders.warn.dragon_pack.body");

        private final String titleKey;
        private final String bodyKey;

        Kind(String titleKey, String bodyKey) {
            this.titleKey = titleKey;
            this.bodyKey = bodyKey;
        }

        public String titleKey() {
            return titleKey;
        }

        public String bodyKey() {
            return bodyKey;
        }
    }

    private final class_437 parent;
    private final Kind kind;
    private final List<String> detailLines;
    private final Runnable onAccept;
    private final String acceptKey;

    public ExperimentalWarningScreen(class_437 parent, Kind kind, List<String> detailLines,
                                     String acceptKey, Runnable onAccept) {
        super(class_2561.method_43471(kind.titleKey()));
        this.parent = parent;
        this.kind = kind;
        this.detailLines = List.copyOf(detailLines);
        this.acceptKey = acceptKey;
        this.onAccept = onAccept;
    }

    @Override
    protected void method_25426() {
        int y = this.field_22790 - 52;
        this.method_37063(class_4185.method_46430(class_2561.method_43471(acceptKey), button -> {
            method_25419();  // Screen#close returns to the parent screen
            if (onAccept != null) {
                onAccept.run();
            }
        }).method_46434(this.field_22789 / 2 - 155, y, 150, 20).method_46431());

        // Cancel is first in tab order and on the left of the primary action: the safe
        // choice should never be the accidental one.
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), button -> method_25419())
                .method_46434(this.field_22789 / 2 + 5, y, 150, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 40, 0xFFAA00);

        List<class_5481> body = this.field_22793.method_1728(class_2561.method_43471(kind.bodyKey()),
                Math.max(180, this.field_22789 - 80));
        int y = 70;
        for (class_5481 line : body) {
            context.method_35719(this.field_22793, line, this.field_22789 / 2, y, 0xDDDDDD);
            y += 11;
        }

        if (!detailLines.isEmpty()) {
            y += 8;
            for (String detail : detailLines) {
                context.method_27534(this.field_22793, class_2561.method_43470(detail),
                        this.field_22789 / 2, y, 0x8FA8BF);
                y += 10;
            }
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}
