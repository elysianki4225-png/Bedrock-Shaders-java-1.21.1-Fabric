package dev.bedrockshaders.client;

import dev.bedrockshaders.BedrockShadersMod;
import dev.bedrockshaders.client.assets.ResourceSource;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;

/**
 * Yarn-side {@link ResourceSource}: the only place the asset loader touches
 * {@code ResourceManager}/{@code Identifier}.
 */
public record FabricResourceSource(class_3300 manager) implements ResourceSource {
    @Override
    public InputStream open(String path) {
        class_2960 identifier = class_2960.method_60655(BedrockShadersMod.MOD_ID, path);
        Optional<class_3298> resource = manager.method_14486(identifier);
        if (resource.isEmpty()) {
            return null;
        }
        try {
            return resource.get().method_14482();
        } catch (IOException e) {
            BedrockShadersMod.LOGGER.warn("Could not open {}", identifier, e);
            return null;
        }
    }

    @Override
    public List<String> list(String directory) {
        List<String> found = new ArrayList<>();
        try {
            manager.method_14488(directory, identifier ->
                            identifier.method_12836().equals(BedrockShadersMod.MOD_ID))
                    .keySet()
                    .forEach(identifier -> found.add(identifier.method_12832()));
        } catch (RuntimeException e) {
            BedrockShadersMod.LOGGER.warn("Could not list {}", directory, e);
        }
        return found;
    }
}
