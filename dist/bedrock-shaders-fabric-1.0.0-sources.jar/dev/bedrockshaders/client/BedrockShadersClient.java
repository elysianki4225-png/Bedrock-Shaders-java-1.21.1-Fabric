package dev.bedrockshaders.client;

import dev.bedrockshaders.BedrockShadersMod;
import dev.bedrockshaders.GamePaths;
import dev.bedrockshaders.client.assets.BedrockAssetLibrary;
import dev.bedrockshaders.client.command.BedrockShadersCommand;
import dev.bedrockshaders.client.pack.BedrockPackImporter;
import dev.bedrockshaders.client.pack.ImportedPackActivator;
import dev.bedrockshaders.client.pack.PackRegistry;
import dev.bedrockshaders.client.pack.RenderDragonSupport;
import dev.bedrockshaders.client.gui.BedrockShadersScreen;
import dev.bedrockshaders.client.render.BedrockPipeline;
import dev.bedrockshaders.client.render.RenderCompat;
import dev.bedrockshaders.client.render.BedrockShaderPack;
import dev.bedrockshaders.client.render.BedrockUniforms;
import dev.bedrockshaders.client.render.ShaderSources;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_2561;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Client entrypoint: loads the config, generates the runtime shader pack, registers
 * the resource reload listeners, the key binding and the {@code /bedrock} command.
 */
public final class BedrockShadersClient implements ClientModInitializer {
    public static final String MOD_ID = BedrockShadersMod.MOD_ID;
    private static class_304 openMenuKey;
    private static class_304 toggleKey;
    private static boolean packRegistered;

    @Override
    public void onInitializeClient() {
        // Fabric is the only loader whose paths are resolved here rather than from an
        // FML service; everything downstream reads GamePaths so the shared pack code stays
        // free of loader imports.
        GamePaths.set(FabricLoader.getInstance().getConfigDir(),
                FabricLoader.getInstance().getGameDir());

        // Decide what may run before anything touches GL. Only the loader can enumerate
        // installed mods, and the answer has to exist before the first frame: under
        // VulkanMod even compiling our post programs would crash the client.
        List<String> modIds = new ArrayList<>();
        for (var mod : FabricLoader.getInstance().getAllMods()) {
            modIds.add(mod.getMetadata().getId());
        }
        RenderCompat.install(FabricLoader.getInstance()::isModLoaded, modIds);

        ConfigManager.get().load();

        // Extension packs load before any pack is imported, so their families are already
        // known when the first pack is classified. Code addons only; the JSON declarations
        // arrive with the first resource reload (see ReloadListener).
        dev.bedrockshaders.api.ExtensionDiscovery.loadServices(
                BedrockShadersClient.class.getClassLoader());

        // Instance folder that behaves like Iris' shaderpacks folder: drop a .mcpack in
        // and it is converted + enabled on this launch.
        PackRegistry.get().ensureFolders();
        PackRegistry.get().load();
        if (ConfigManager.get().config().autoImportPacks) {
            List<BedrockPackImporter.Result> imported = PackRegistry.get().importPending();
            for (BedrockPackImporter.Result result : imported) {
                if (!result.success()) {
                    BedrockShadersMod.LOGGER.warn("Bedrock pack import skipped: {}", result.message());
                }
            }
            if (!imported.isEmpty()) {
                BedrockShadersMod.LOGGER.info("Imported {} Bedrock archive(s) from {}",
                        imported.size(), PackRegistry.importFolder());
                reportImported(imported);
            }
        }

        BedrockShaderPack.setPackRoot(FabricLoader.getInstance().getConfigDir()
                .resolve("bedrock-shaders").resolve("pack"));

        // The built-in pack overrides five vanilla core shader programs. With Iris installed
        // that is a direct fight over the same programs and the same framebuffer, so it is
        // not registered at all: the imported .mcpack data still applies through the
        // resource-pack stack that Iris itself loads.
        if (RenderCompat.get().allowsGlWork()) {
            FabricLoader.getInstance().getModContainer(MOD_ID).ifPresent(container ->
                    packRegistered = ResourceManagerHelper.registerBuiltinResourcePack(
                            class_2960.method_60655(MOD_ID, "runtime_shaders"),
                            container,
                            class_2561.method_43470("Bedrock Shaders (runtime)"),
                            ResourcePackActivationType.DEFAULT_ENABLED));
        } else {
            BedrockShadersMod.LOGGER.info(
                    "Bedrock runtime shader pack not registered: {}", RenderCompat.get().reason());
        }

        // The render pipeline only needs three values from the main framebuffer; keep the
        // game-type dependency here so the pipeline stays loader-agnostic.
        BedrockPipeline.setMainFramebufferSupplier(() -> {
            var framebuffer = class_310.method_1551().method_1522();
            return new dev.bedrockshaders.client.render.VanillaFramebuffer() {
                @Override
                public int framebufferId() {
                    return framebuffer.field_1476;
                }

                @Override
                public int width() {
                    return framebuffer.field_1482;
                }

                @Override
                public int height() {
                    return framebuffer.field_1481;
                }
            };
        });

        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new ReloadListener());

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                BedrockShadersCommand.register(dispatcher));

        openMenuKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.bedrock_shaders.open_menu",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F9,
                "key.categories.bedrock_shaders"));
        toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.bedrock_shaders.toggle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F10,
                "key.categories.bedrock_shaders"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (pendingPackSync) {
                pendingPackSync = false;
                ImportedPackActivator.reload(client);
            }
            // One-time hint on first join: without it a new player has no way to know the
            // menu exists or that a key toggles the renderer.
            // RenderDragon warnings queued during init/import, delivered once a player exists.
            if (!PENDING_WARNINGS.isEmpty() && client.field_1724 != null) {
                // Drain by index: a warning queued while this loop runs (an import finishing
                // mid-tick) must survive to the next tick instead of being cleared unseen.
                class_2561 warning;
                while ((warning = PENDING_WARNINGS.poll()) != null) {
                    client.field_1724.method_7353(warning, false);
                }
            }
            if (pendingWelcome && client.field_1724 != null && client.field_1687 != null) {
                pendingWelcome = false;
                client.field_1724.method_7353(class_2561.method_43469("bedrock_shaders.message.welcome",
                        openMenuKey.method_16007(),
                        toggleKey.method_16007()), false);
            }
            while (openMenuKey.method_1436()) {
                if (client.field_1755 == null) {
                    ConfigManager.get().armUndoOnOpen();
                    client.method_1507(new BedrockShadersScreen(null));
                }
            }
            while (toggleKey.method_1436()) {
                boolean enabled = !ConfigManager.get().config().enabled;
                ConfigManager.get().edit(config -> config.enabled = enabled);
                ConfigManager.get().save();
                BedrockShaderPack.regenerateFromCurrentResources();
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(class_2561.method_43471(enabled
                            ? "bedrock_shaders.message.enabled"
                            : "bedrock_shaders.message.disabled"), true);
                }
            }
        });

        BedrockShadersMod.LOGGER.info("Bedrock Shaders client initialised (builtin pack: {}, import folder: {})",
                packRegistered, PackRegistry.importFolder());
    }

    /** Set once the client is far enough through startup for a resource reload. */
    private static boolean pendingPackSync = true;

    /** Cleared after the first join, so the welcome hint shows exactly once per launch. */
    private static boolean pendingWelcome = true;

    /**
     * Chat warnings about RenderDragon packs, queued because imports run during client
     * initialisation, when there is no player to talk to yet.
     */
    private static final java.util.Queue<class_2561> PENDING_WARNINGS = new java.util.concurrent.ConcurrentLinkedQueue<>();

    /**
     * Records what an import run found and queues one warning per RenderDragon archive.
     *
     * <p>Called for automatic and manual imports alike. A failure that already explains
     * itself ("RenderDragon pack ... support is off") is queued too: the user dropped a file
     * and needs to know why nothing happened.</p>
     */
    public static void reportImported(java.util.List<BedrockPackImporter.Result> results) {
        for (BedrockPackImporter.Result result : results) {
            if (!result.renderDragon()) {
                continue;
            }
            RenderDragonSupport.Detection detection = result.detection();
            class_2561 message;
            if (result.success()) {
                message = class_2561.method_43469("bedrock_shaders.message.dragon_imported",
                        detection.dataFiles(), detection.binaries());
            } else if (ConfigManager.get().config().experimentalRenderDragon) {
                message = class_2561.method_43469("bedrock_shaders.message.dragon_no_data",
                        detection.binaries());
            } else {
                message = class_2561.method_43469("bedrock_shaders.message.dragon_switch_off",
                        detection.binaries());
            }
            PENDING_WARNINGS.add(message);
            BedrockShadersMod.LOGGER.warn("RenderDragon pack noticed: {} ({})",
                    result.message(), detection.describe());
        }
    }

    public static boolean isPackRegistered() {
        return packRegistered;
    }

    /** Resource reload: refresh shader sources, Bedrock assets and regenerate the pack. */
    private static final class ReloadListener implements SimpleSynchronousResourceReloadListener {
        private static final class_2960 ID = class_2960.method_60655(MOD_ID, "renderer");

        @Override
        public class_2960 getFabricId() {
            return ID;
        }

        /**
         * Reads every {@code assets/<ns>/bedrock_shaders/api.json} the loaded packs provide,
         * so a pack author can register families without writing Java.
         *
         * <p>Runs on every resource reload, which includes opening the pack selection screen.
         * Registration is idempotent by family id, so the noise is a debug-level refusal
         * rather than a duplicate family.</p>
         */
        private static void loadExtensionDeclarations(class_3300 manager) {
            try {
                var found = manager.method_14488("bedrock_shaders",
                        id -> id.method_12832().endsWith("api.json"));
                for (var entry : found.entrySet()) {
                    try (var stream = entry.getValue().method_14482()) {
                        String json = new String(stream.readAllBytes(),
                                java.nio.charset.StandardCharsets.UTF_8);
                        dev.bedrockshaders.api.JsonExtensionLoader.load(
                                entry.getKey().toString(), json);
                    } catch (IOException | RuntimeException e) {
                        BedrockShadersMod.LOGGER.warn("Could not read extension declaration {}: {}",
                                entry.getKey(), e.toString());
                    }
                }
            } catch (RuntimeException e) {
                // Discovery is a nicety: a resource manager that cannot list must not break
                // the renderer reload.
                BedrockShadersMod.LOGGER.warn("Extension discovery skipped: {}", e.toString());
            }
        }

        @Override
        public void method_14491(class_3300 manager) {
            ShaderSources.clearCache();
            FabricResourceSource source = new FabricResourceSource(manager);
            BedrockShaderPack.setCurrentSource(source);
            ShaderSources.reload(source);
            BedrockAssetLibrary.get().reload(source);
            BedrockUniforms.invalidate();
            BedrockShaderPack.setCurrentSource(source);
            if (RenderCompat.get().allowsGlWork()) {
                BedrockShaderPack.ensureGenerated(source, true);
            }
            ImportedPackActivator.invalidate();
            loadExtensionDeclarations(manager);
            class_310 client = class_310.method_1551();
            if (client != null && client.field_1687 == null) {
                // Outside a world the pipeline is recreated lazily on the next frame.
                BedrockPipeline.get().close();
            }
        }
    }
}
