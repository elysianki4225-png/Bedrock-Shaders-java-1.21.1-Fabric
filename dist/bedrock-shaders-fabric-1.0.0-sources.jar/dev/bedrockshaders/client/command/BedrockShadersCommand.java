package dev.bedrockshaders.client.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.bedrockshaders.api.ExtensionRegistry;
import dev.bedrockshaders.api.ExtensionRegistry.Entry;
import dev.bedrockshaders.bedrock.FogSettings;
import dev.bedrockshaders.client.ConfigManager;
import dev.bedrockshaders.client.assets.BedrockAssetLibrary;
import dev.bedrockshaders.client.gui.BedrockShadersScreen;
import dev.bedrockshaders.client.pack.BedrockPackImporter.Result;
import dev.bedrockshaders.client.pack.PackRegistry;
import dev.bedrockshaders.client.render.BedrockPipeline;
import dev.bedrockshaders.client.render.BedrockShaderPack;
import dev.bedrockshaders.client.render.FrameContext;
import dev.bedrockshaders.client.render.RenderCompat;
import dev.bedrockshaders.config.QualityPreset;
import dev.bedrockshaders.config.ShaderFamily;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_2561;
import net.minecraft.class_310;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/**
 * Client-side command tree:
 * <pre>
 *   /bedrock menu                       open the settings screen
 *   /bedrock toggle                     enable / disable the pipeline
 *   /bedrock preset &lt;potato..ultra&gt;
 *   /bedrock reload                     regenerate the shader pack and reload resources
 *   /bedrock debug                      log pipeline diagnostics
 *   /bedrock fog                        print the active Bedrock biome bindings
 *   /bedrock effects                    list every loaded Bedrock fog identifier
 * </pre>
 */
public final class BedrockShadersCommand {
    private BedrockShadersCommand() {
    }

    private static int openMenu() {
        class_310.method_1551().execute(() -> {
            ConfigManager.get().armUndoOnOpen();
            class_310.method_1551().method_1507(new BedrockShadersScreen(null));
        });
        return 1;
    }

    /**
     * Prints the extension API state: what is installed, what registered, and what failed.
     *
     * <p>This is the support command. A pack author reporting "my extension does nothing" gets
     * told whether it was even seen, whether it registered, and how many times it threw.</p>
     */
    private static int printApiStatus(FabricClientCommandSource source) {
        var registry = dev.bedrockshaders.api.ExtensionRegistry.get();
        var entries = registry.entries();
        source.sendFeedback(class_2561.method_43470("Bedrock Shaders extension API v"
                + dev.bedrockshaders.api.BedrockShadersApi.API_VERSION));
        if (entries.isEmpty()) {
            source.sendFeedback(class_2561.method_43470("  no extension packs installed"));
        } else {
            for (var entry : entries) {
                source.sendFeedback(class_2561.method_43470("  " + entry.id()
                        + " v" + entry.apiVersion()
                        + (entry.name().isBlank() ? "" : " (" + entry.name() + ")")
                        + (entry.disabled() ? " DISABLED after " + entry.failures() + " failure(s)"
                                : entry.failures() > 0 ? " " + entry.failures() + " failure(s)" : "")
                        + (entry.registeredFamilies().isBlank()
                                ? "" : " families: " + entry.registeredFamilies())));
            }
        }
        source.sendFeedback(class_2561.method_43470("  frame hooks: " + registry.frameHooks().size()
                + ", preprocessors: " + registry.preprocessors().size()
                + ", extension families: " + registry.families().size()));
        source.sendFeedback(class_2561.method_43470("  /bedrock api guide|families for details"));
        return 1;
    }

    /** Opens the settings screen. */
    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        LiteralArgumentBuilder<FabricClientCommandSource> root = literal("bedrock")
                .executes(ctx -> openMenu())
                .then(literal("menu").executes(ctx -> openMenu()))
                .then(literal("toggle").executes(ctx -> {
                    boolean enabled = !ConfigManager.get().config().enabled;
                    ConfigManager.get().edit(config -> config.enabled = enabled);
                    ConfigManager.get().save();
                    BedrockShaderPack.regenerateFromCurrentResources();
                    ctx.getSource().sendFeedback(class_2561.method_43471(enabled
                            ? "bedrock_shaders.message.enabled"
                            : "bedrock_shaders.message.disabled"));
                    return 1;
                }))
                .then(literal("preset")
                        .then(argument("name", com.mojang.brigadier.arguments.StringArgumentType.word())
                                .suggests((ctx, builder) -> {
                                    for (QualityPreset preset : QualityPreset.values()) {
                                        builder.suggest(preset.id);
                                    }
                                    return builder.buildFuture();
                                })
                                .executes(ctx -> {
                                    String name = com.mojang.brigadier.arguments.StringArgumentType.getString(ctx, "name");
                                    QualityPreset preset = QualityPreset.byId(name);
                                    ConfigManager.get().pushUndo();
                                    ConfigManager.get().edit(config -> config.applyPreset(preset));
                                    ConfigManager.get().save();
                                    ctx.getSource().sendFeedback(class_2561.method_43470("Bedrock Shaders preset: " + preset.id));
                                    return 1;
                                })))
                .then(literal("reload").executes(ctx -> {
                    ConfigManager.get().load();
                    BedrockShaderPack.regenerateFromCurrentResources();
                    class_310 client = class_310.method_1551();
                    client.method_1521();
                    ctx.getSource().sendFeedback(class_2561.method_43470("Bedrock Shaders: regenerated the runtime shader pack"));
                    return 1;
                }))
                .then(literal("debug").executes(ctx -> {
                    BedrockPipeline pipeline = BedrockPipeline.get();
                    FrameContext frame = FrameContext.get();
                    var assets = BedrockAssetLibrary.get();
                    ctx.getSource().sendFeedback(class_2561.method_43470(
                            "Bedrock pipeline ready=" + pipeline.isReady()
                                    + " assets=" + assets.parsedFiles() + " files / " + assets.loadErrors() + " errors"
                                    + " fog=" + frame.fogId()
                                    + " sun=" + String.format("%.2f", frame.sunIntensity())
                                    + " moon=" + String.format("%.2f", frame.moonIntensity())
                                    + " time=" + String.format("%.2f", frame.sunAngle())
                                    + " biome=" + frame.biomeId()
                                    + " pack=" + (frame.activePackName().isEmpty() ? "builtin" : frame.activePackName())
                                    + " family=" + frame.shaderFamily().id
                                    + " compat=" + RenderCompat.get().mode()
                                    + " (" + RenderCompat.get().reason() + ")"));
                    return 1;
                }))
                .then(literal("fog").executes(ctx -> {
                    FrameContext frame = FrameContext.get();
                    var fog = frame.fogSettings();
                    ctx.getSource().sendFeedback(class_2561.method_43470(
                            "Bedrock fog id=" + frame.fogId() + " file=" + fog.identifier
                                    + " air=[" + fog.airStart + ", " + fog.airEnd + "]"
                                    + " water=[" + fog.waterStart + ", " + fog.waterEnd + "]"
                                    + " volumetric=" + fog.volumetricAirMaxDensity));
                    return 1;
                }))
                .then(literal("import").executes(ctx -> {
                    var registry = dev.bedrockshaders.client.pack.PackRegistry.get();
                    registry.ensureFolders();
                    var results = registry.importPending();
                    dev.bedrockshaders.client.pack.ImportedPackActivator.invalidate();
                    dev.bedrockshaders.client.pack.ImportedPackActivator.reload(class_310.method_1551());
                    if (results.isEmpty()) {
                        ctx.getSource().sendFeedback(class_2561.method_43469("bedrock_shaders.command.import.none",
                                registry.importFolder().toString()));
                    } else {
                        int ok = 0;
                        for (var result : results) {
                            if (result.success()) {
                                ok++;
                                ctx.getSource().sendFeedback(class_2561.method_43470("  + " + result.message()));
                            } else {
                                ctx.getSource().sendFeedback(class_2561.method_43470("  ! " + result.message()));
                            }
                        }
                        ctx.getSource().sendFeedback(class_2561.method_43469("bedrock_shaders.command.import.done",
                                ok, results.size() - ok));
                    }
                    return results.size();
                }))
                .then(literal("packs").executes(ctx -> {
                    class_310.method_1551().execute(() -> class_310.method_1551()
                            .method_1507(new dev.bedrockshaders.client.gui.BedrockPacksScreen(null)));
                    return 1;
                }))
                .then(literal("api")
                        .executes(ctx -> printApiStatus(ctx.getSource()))
                        .then(literal("guide").executes(ctx -> {
                            for (String line : dev.bedrockshaders.api.ExtensionDiscovery.guide()) {
                                ctx.getSource().sendFeedback(class_2561.method_43470(line));
                            }
                            return 1;
                        }))
                        .then(literal("families").executes(ctx -> {
                            var registry = dev.bedrockshaders.api.ExtensionRegistry.get();
                            var builtIn = new java.util.ArrayList<String>();
                            for (var family : dev.bedrockshaders.config.ShaderFamily.values()) {
                                builtIn.add(family.id);
                            }
                            ctx.getSource().sendFeedback(class_2561.method_43470(
                                    "Built-in families: " + String.join(", ", builtIn)));
                            var custom = registry.familyIdsSnapshot();
                            ctx.getSource().sendFeedback(class_2561.method_43470(custom.isEmpty()
                                    ? "Extension families: none registered"
                                    : "Extension families: " + String.join(", ", custom)));
                            return 1;
                        })))
                .then(literal("effects").executes(ctx -> {
                    var assets = BedrockAssetLibrary.get();
                    var ids = assets.fogIdentifiers();
                    ctx.getSource().sendFeedback(class_2561.method_43470(
                            "Loaded " + ids.size() + " Bedrock effects: " + String.join(", ",
                                    ids.subList(0, Math.min(ids.size(), 12)))
                                    + (ids.size() > 12 ? "..." : "")));
                    return 1;
                }));
        dispatcher.register(root);
    }
}
