package dev.bedrockshaders.client.gui;

import dev.bedrockshaders.client.BedrockShadersClient;
import dev.bedrockshaders.client.ConfigManager;
import dev.bedrockshaders.client.assets.BedrockAssetLibrary;
import dev.bedrockshaders.client.pack.PackRegistry;
import dev.bedrockshaders.client.render.BedrockPipeline;
import dev.bedrockshaders.client.render.BedrockShaderPack;
import dev.bedrockshaders.client.render.FrameContext;
import dev.bedrockshaders.config.BedrockConfig;
import dev.bedrockshaders.config.QualityPreset;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;


/**
 * In-game Bedrock Shaders settings: a three-column, page-based menu that edits the
 * live {@link BedrockConfig}. Every change is applied immediately, so the user sees
 * the result behind the (translucent) menu.
 */
public final class BedrockShadersScreen extends class_437 {
    private static final int COLUMN_WIDTH = 200;
    private static final int ROW_HEIGHT = 20;
    private static final int ROW_GAP = 4;

    private enum Page {
        PRESETS("bedrock_shaders.page.presets"),
        ATMOSPHERE("bedrock_shaders.page.atmosphere"),
        WATER("bedrock_shaders.page.water"),
        EFFECTS("bedrock_shaders.page.effects"),
        PACKS("bedrock_shaders.page.packs"),
        GRADE("bedrock_shaders.page.grade"),
        SYSTEM("bedrock_shaders.page.system");

        final String translationKey;

        Page(String translationKey) {
            this.translationKey = translationKey;
        }
    }

    private final class_437 parent;
    private Page page = Page.PRESETS;

    public BedrockShadersScreen(class_437 parent) {
        super(class_2561.method_43471("bedrock_shaders.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        ConfigManager.get().pushUndoOnce();
        ConfigManager.get().armUndoOnOpen();
        if (ConfigManager.get().config() == null) {
            return;
        }
        int centerX = field_22789 / 2;
        int top = 44;
        buildPage(top, centerX);
        addPageButtons(centerX);

        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), button -> method_25419())
                .method_46434(centerX - 100, field_22790 - 28, 200, 20).method_46431());
    }

    private void addPageButtons(int centerX) {
        Page[] pages = Page.values();
        int pageWidth = Math.min(120, (field_22789 - 20) / pages.length);
        int totalWidth = pageWidth * pages.length;
        int left = centerX - totalWidth / 2;
        for (int i = 0; i < pages.length; i++) {
            Page value = pages[i];
            class_4185 button = class_4185.method_46430(class_2561.method_43471(value.translationKey), b -> {
                page = value;
                rebuild();
            }).method_46434(left + i * pageWidth, 20, pageWidth - 2, 20).method_46431();
            button.field_22763 = value != page;
            method_37063(button);
        }
    }

    /** Rebuilds the widgets for the current page (Screen#clearAndInit is final). */
    private void rebuild() {
        this.method_37067();
        this.method_25426();
    }

    private void buildPage(int top, int centerX) {
        BedrockConfig config = ConfigManager.get().config();
        switch (page) {
            case PRESETS -> {
                int y = top;
                for (QualityPreset preset : QualityPreset.values()) {
                    method_37063(class_4185.method_46430(
                                    class_2561.method_43471("bedrock_shaders.preset." + preset.id),
                                    button -> applyPreset(preset))
                            .method_46434(centerX - 100, y, 200, ROW_HEIGHT).method_46431());
                    y += ROW_HEIGHT + ROW_GAP;
                }
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.enabled",
                        config.enabled, value -> config.enabled = value));
            }
            case ATMOSPHERE -> {
                int y = top;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.atmosphere",
                        config.atmosphere, value -> config.atmosphere = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.sky",
                        config.replaceVanillaSky, value -> config.replaceVanillaSky = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.clouds",
                        config.clouds, value -> config.clouds = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.stars",
                        config.stars, value -> config.stars = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.fog_density",
                        config.fogDensity, 0.0F, 3.0F, value -> config.fogDensity = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.sun_intensity",
                        config.sunIntensity, 0.0F, 3.0F, value -> config.sunIntensity = value));
            }
            case WATER -> {
                int y = top;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.water",
                        config.water, value -> config.water = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.wave_strength",
                        config.waterWaveStrength, 0.0F, 3.0F, value -> config.waterWaveStrength = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.reflections",
                        config.waterReflectionStrength, 0.0F, 1.0F, value -> config.waterReflectionStrength = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.refraction",
                        config.waterRefractionStrength, 0.0F, 2.0F, value -> config.waterRefractionStrength = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.caustics",
                        config.caustics, 0.0F, 2.0F, value -> config.caustics = value));
            }
            case EFFECTS -> {
                int y = top;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.ssao",
                        config.ssao, value -> config.ssao = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.ssao_strength",
                        config.ssaoStrength, 0.0F, 2.0F, value -> config.ssaoStrength = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.bloom",
                        config.bloom, value -> config.bloom = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.bloom_strength",
                        config.bloomStrength, 0.0F, 1.5F, value -> config.bloomStrength = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.godrays",
                        config.godrays, value -> config.godrays = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.godray_strength",
                        config.godrayStrength, 0.0F, 3.0F, value -> config.godrayStrength = value));
            }
            case GRADE -> {
                int y = top;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.tonemap",
                        config.tonemap, value -> config.tonemap = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.exposure",
                        config.exposure, 0.2F, 3.0F, value -> config.exposure = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.saturation",
                        config.saturation, 0.0F, 2.0F, value -> config.saturation = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(slider(centerX - 100, y, 200, "bedrock_shaders.option.contrast",
                        config.contrast, 0.5F, 2.0F, value -> config.contrast = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(class_4185.method_46430(class_2561.method_43471("bedrock_shaders.action.reset_grade"),
                        button -> {
                            ConfigManager.get().edit(c -> {
                                c.saturation = 1.0F;
                                c.contrast = 1.0F;
                                c.exposure = 1.0F;
                            });
                        }).method_46434(centerX - 100, y, 200, ROW_HEIGHT).method_46431());
            }
            case PACKS -> {
                int y = top;
                method_37063(class_4185.method_46430(class_2561.method_43471("bedrock_shaders.action.open_packs"),
                        button -> class_310.method_1551().method_1507(new BedrockPacksScreen(this)))
                        .method_46434(centerX - 100, y, 200, ROW_HEIGHT).method_46431());
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.auto_import",
                        config.autoImportPacks, value -> config.autoImportPacks = value));
                y += ROW_HEIGHT + ROW_GAP;
                int imported = dev.bedrockshaders.client.pack.PackRegistry.get().imported().size();
                method_37063(class_4185.method_46430(
                                class_2561.method_43469("bedrock_shaders.action.import_now", imported),
                                button -> {
                                    var registry = dev.bedrockshaders.client.pack.PackRegistry.get();
                                    registry.ensureFolders();
                                    registry.importPending();
                                    dev.bedrockshaders.client.pack.ImportedPackActivator.invalidate();
                                    dev.bedrockshaders.client.pack.ImportedPackActivator.reload(class_310.method_1551());
                                    rebuild();
                                })
                        .method_46434(centerX - 100, y, 200, ROW_HEIGHT).method_46431());
            }
            case SYSTEM -> {
                int y = top;
                method_37063(class_4185.method_46430(class_2561.method_43471("bedrock_shaders.action.reload_shaders"),
                        button -> {
                            BedrockShaderPack.regenerateFromCurrentResources();
                            class_310.method_1551().method_1521();
                        }).method_46434(centerX - 100, y, 200, ROW_HEIGHT).method_46431());
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(toggle(centerX - 100, y, 200, "bedrock_shaders.option.debug",
                        config.debugOverlay, value -> config.debugOverlay = value));
                y += ROW_HEIGHT + ROW_GAP;
                method_37063(class_4185.method_46430(class_2561.method_43471("bedrock_shaders.action.reset_all"),
                        button -> ConfigManager.get().resetToDefaults())
                        .method_46434(centerX - 100, y, 200, ROW_HEIGHT).method_46431());
            }
        }
    }

    private void applyPreset(QualityPreset preset) {
        ConfigManager.get().pushUndo();
        ConfigManager.get().edit(config -> config.applyPreset(preset));
        rebuild();
    }

    private class_5676<Boolean> toggle(int x, int y, int width, String key, boolean initial,
                                                java.util.function.Consumer<Boolean> setter) {
        return class_5676.method_32614()
                .method_32619(initial)
                .method_32617(x, y, width, ROW_HEIGHT, class_2561.method_43471(key),
                        (button, value) -> {
                            setter.accept(value);
                            ConfigManager.get().markDirty();
                        });
    }

    private class_357 slider(int x, int y, int width, String key, float initial, float min, float max,
                                java.util.function.Consumer<Float> setter) {
        return new ValueSlider(x, y, width, ROW_HEIGHT, class_2561.method_43471(key), initial, min, max, setter);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_52752(context);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 6, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);

        BedrockPipeline pipeline = BedrockPipeline.get();
        FrameContext frame = FrameContext.get();
        BedrockAssetLibrary assets = BedrockAssetLibrary.get();
        String status = class_2561.method_43469("bedrock_shaders.status.line",
                pipeline.isReady() ? class_2561.method_43471("bedrock_shaders.status.active")
                        : class_2561.method_43471("bedrock_shaders.status.fallback"),
                assets.parsedFiles(), frame.fogId()).getString();
        context.method_27534(field_22793, class_2561.method_43470(status), field_22789 / 2, field_22790 - 44, 0x9BB7D4);
        if (ConfigManager.get().isDirty()) {
            context.method_27535(field_22793,
                    class_2561.method_43471("bedrock_shaders.hint.unsaved"), 6, field_22790 - 52, 0xE0C060);
        }
    }

    @Override
    public void method_25419() {
        ConfigManager.get().save();
        class_310 client = class_310.method_1551();
        client.method_1507(parent);
    }

    /** A float slider with a keyboard/step-friendly API. */
    private static final class ValueSlider extends class_357 {
        private final float min;
        private final float max;
        private final java.util.function.Consumer<Float> setter;
        private final class_2561 label;

        ValueSlider(int x, int y, int width, int height, class_2561 label, float value, float min, float max,
                    java.util.function.Consumer<Float> setter) {
            super(x, y, width, height, label, (value - min) / (max - min));
            this.min = min;
            this.max = max;
            this.setter = setter;
            this.label = label;
            method_25346();
        }

        @Override
        protected void method_25346() {
            float current = min + (max - min) * (float) this.field_22753;
            method_25355(class_2561.method_43469("bedrock_shaders.slider", label, String.format("%.2f", current)));
        }

        @Override
        protected void method_25344() {
            setter.accept(min + (float) (max - min) * (float) this.field_22753);
            ConfigManager.get().markDirty();
        }
    }
}
