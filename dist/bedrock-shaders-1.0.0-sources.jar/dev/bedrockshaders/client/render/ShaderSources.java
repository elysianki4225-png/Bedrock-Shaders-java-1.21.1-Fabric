package dev.bedrockshaders.client.render;

import dev.bedrockshaders.BedrockShadersMod;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;

/**
 * Loads the Bedrock shader sources that ship in the jar at
 * {@code assets/bedrock_shaders/bedrockshader/*} and prepares them for vanilla's
 * core-shader importer by flattening {@code #moj_import <...>} includes.
 *
 * <p>Sources are reloaded on resource reloads so pack overrides are respected.</p>
 */
public final class ShaderSources {
    private static final String ROOT = "bedrockshader/";
    private static final Map<String, String> CACHE = new HashMap<>();

    private ShaderSources() {
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(BedrockShadersMod.MOD_ID, ROOT + path);
    }

    public static void clearCache() {
        CACHE.clear();
    }

    /** Returns the fully flattened GLSL for {@code core/<name>.vsh|fsh}. */
    public static String get(class_3300 manager, String stage) {
        String cached = CACHE.get(stage);
        if (cached != null) {
            return cached;
        }
        String source = readRaw(manager, "core/" + stage);
        String flattened = flatten(manager, source, 0);
        CACHE.put(stage, flattened);
        return flattened;
    }

    private static String readRaw(class_3300 manager, String path) {
        class_2960 identifier = id(path);
        Optional<class_3298> resource = manager.method_14486(identifier);
        if (resource.isEmpty()) {
            throw new IllegalStateException("Missing Bedrock shader source " + identifier);
        }
        try (InputStream stream = resource.get().method_14482()) {
            return new String(stream.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException("Could not read " + identifier, e);
        }
    }

    /**
     * Flattens {@code #moj_import <name>} directives exactly like vanilla's
     * {@code GlImportProcessor}, but also supports {@code #moj_import "name"}.
     * Include files must reside under {@code bedrockshader/include/}.
     */
    public static String flatten(class_3300 manager, String source, int depth) {
        if (depth > 8) {
            throw new IllegalStateException("Bedrock shader include depth exceeded");
        }
        StringBuilder out = new StringBuilder(source.length() + 4096);
        for (String line : source.split("\n", -1)) {
            String trimmed = line.trim();
            if (trimmed.startsWith("#moj_import")) {
                String target = trimmed.substring("#moj_import".length()).trim();
                if (target.startsWith("<") && target.endsWith(">")) {
                    target = target.substring(1, target.length() - 1);
                } else if (target.startsWith("\"") && target.endsWith("\"")) {
                    target = target.substring(1, target.length() - 1);
                }
                String included = flatten(manager, readRaw(manager, "include/" + target), depth + 1);
                out.append("// begin ").append(target).append('\n');
                out.append(included);
                out.append("// end ").append(target).append('\n');
            } else {
                out.append(line);
                out.append('\n');
            }
        }
        return out.toString();
    }

    /** Called by the resource reload listener. */
    public static void reload(class_310 client) {
        clearCache();
        if (client == null) {
            return;
        }
        for (String stage : new String[] {
                "bedrock_terrain.vsh", "bedrock_terrain.fsh",
                "bedrock_translucent.vsh", "bedrock_translucent.fsh",
                "bedrock_entity.vsh", "bedrock_entity.fsh"}) {
            try {
                ShaderSources.get(client.method_1478(), stage);
            } catch (RuntimeException e) {
                BedrockShadersMod.LOGGER.warn("Bedrock shader source {} unavailable", stage, e);
            }
        }
    }
}
