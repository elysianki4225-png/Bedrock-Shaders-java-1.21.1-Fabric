package dev.bedrockshaders.client;

import dev.bedrockshaders.client.render.ClientSnapshot;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_746;

/**
 * Yarn-side implementation of {@link ClientSnapshot}. This is the only place the frame
 * calculation touches Yarn names, so the Forge/NeoForge ports only need their own copy of
 * this one class instead of a rewrite of {@code FrameContext}.
 */
public final class FabricClientSnapshot implements ClientSnapshot {
    private static final FabricClientSnapshot INSTANCE = new FabricClientSnapshot();

    private final class_310 client = class_310.method_1551();
    private class_638 world;
    private class_746 player;

    private FabricClientSnapshot() {
    }

    /** Reused every frame; the getters read live state. */
    public static FabricClientSnapshot get() {
        return INSTANCE;
    }

    /** Refreshes the cached world/player; call once per frame before the getters. */
    public FabricClientSnapshot refresh() {
        this.world = client.field_1687;
        this.player = client.field_1724;
        return this;
    }

    private class_638 world() {
        return world != null ? world : client.field_1687;
    }

    @Override
    public boolean inWorld() {
        return refresh().world != null && player != null;
    }

    @Override
    public String dimensionKey() {
        class_638 current = world();
        return current == null ? "" : current.method_27983().method_29177().toString();
    }

    @Override
    public float tickDelta() {
        return client.method_60646().method_60637(false);
    }

    @Override
    public double cameraX() {
        return client.field_1773.method_19418().method_19326().field_1352;
    }

    @Override
    public double cameraY() {
        return client.field_1773.method_19418().method_19326().field_1351;
    }

    @Override
    public double cameraZ() {
        return client.field_1773.method_19418().method_19326().field_1350;
    }

    @Override
    public int framebufferWidth() {
        return client.method_22683().method_4489();
    }

    @Override
    public int framebufferHeight() {
        return client.method_22683().method_4506();
    }

    @Override
    public float viewDistanceBlocks() {
        return client.field_1690.method_42503().method_41753() * 16.0F;
    }

    @Override
    public long dayTime() {
        class_638 current = world();
        return current == null ? 0L : current.method_8532();
    }

    @Override
    public float skyAngle(float tickDelta) {
        class_638 current = world();
        return current == null ? 0.0F : current.method_30274(tickDelta);
    }

    @Override
    public float rainLevel(float tickDelta) {
        class_638 current = world();
        return current == null ? 0.0F : current.method_8430(tickDelta);
    }

    @Override
    public float thunderLevel(float tickDelta) {
        class_638 current = world();
        return current == null ? 0.0F : current.method_8478(tickDelta);
    }

    @Override
    public float skyDarken(float tickDelta) {
        return client.field_1773.method_3195(tickDelta);
    }

    @Override
    public boolean cameraInWater() {
        return client.field_1773.method_19418().method_19334()
                == net.minecraft.class_5636.field_27886;
    }

    @Override
    public String biomeId(double x, double y, double z) {
        class_638 current = world();
        if (current == null) {
            return "";
        }
        class_6880<class_1959> entry = current.method_23753(class_2338.method_49637(x, y, z));
        return entry.method_40230().map(key -> key.method_29177().toString()).orElse("");
    }

    @Override
    public float biomeTemperature(double x, double y, double z) {
        class_638 current = world();
        return current == null ? 0.8F : current.method_23753(class_2338.method_49637(x, y, z)).comp_349().method_8712();
    }

    @Override
    public boolean biomeHasPrecipitation(double x, double y, double z) {
        class_638 current = world();
        return current != null && current.method_23753(class_2338.method_49637(x, y, z)).comp_349().method_48163();
    }

    @Override
    public int minBuildHeight() {
        class_638 current = world();
        return current == null ? -64 : current.method_31607();
    }

    @Override
    public int maxBuildHeight() {
        class_638 current = world();
        return current == null ? 320 : current.method_31600();
    }

    @Override
    public float waterSurfaceHeight(int x, int startY, int z, float fallback) {
        class_638 current = world();
        if (current == null) {
            return fallback;
        }
        class_2338.class_2339 pos = new class_2338.class_2339(x, Math.min(startY, maxBuildHeight() - 1), z);
        for (int y = pos.method_10264(); y >= minBuildHeight(); y--) {
            pos.method_33098(y);
            class_2680 state = current.method_8320(pos);
            var fluid = state.method_26227();
            if (!fluid.method_15769() && fluid.method_15771()) {
                return (float) y + fluid.method_20785();
            }
            if (state.method_26216(current, pos) && y < startY - 1) {
                // Hit solid ground without finding water: no water body here.
                return fallback;
            }
        }
        return fallback;
    }
}
